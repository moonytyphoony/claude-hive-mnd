# Video knowledge integration

Ask the user for a transcript file (.txt or .vtt) and an HTTPS YouTube URL. Do not claim the video has been watched or independently verified. Use `node scripts/hive-intelligence.mjs youtube URL FILE hive.json TITLE` to add it to the same Hive graph as encyclopedia pages. Use `node scripts/hive-intelligence.mjs context hive.json "question"` for bounded relevant passages, with source URLs. Do not claim fine-tuning or model training.
