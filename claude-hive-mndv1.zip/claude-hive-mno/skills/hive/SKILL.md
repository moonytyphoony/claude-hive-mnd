---
name: hive
description: Use when the user wants to map project conversations or research into a Claude Hive graph, find links between topics, or export a self-contained knowledge bundle.
---

# Claude Hive

Help the user create a knowledge graph for the Claude Hive web app. The user controls which information is included; do **not** automatically read their private conversation directories, account tokens, unrelated files, or cloud drives.

When asked to export their current project:
1. Ask which project information or transcripts they want included (unless already specified).
2. Summarize each significant idea in a clear title and a concise Markdown note.
3. Add `tags` for related themes; use `[[Title]]` for explicit relationships.
4. Generate a `claude-hive.json` file compliant with the project data format, with `version: 1` and a `nodes` array containing `id`, `title`, `content`, `tags`, `type`, `createdAt`, `updatedAt`.
5. Point them to the browser-based viewer described in the repository README. Cloud sync requires user authorization in the website, not in Claude Code.

You may run `node scripts/claude-to-hive.mjs PATH_TO_EXPLICITLY_SELECTED_JSONL_DIR OUTPUT_PATH` when the user has named their own Claude Code transcript folder and asks for a graph of it. Never include secrets in generated notes. Ensure the user understands the export may contain sensitive conversation content.
