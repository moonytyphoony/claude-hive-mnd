import test from 'node:test';
import assert from 'node:assert/strict';
import {parseImport,normalizeNote,makeBackup,validateHive,SAMPLE} from '../assets/data.js';
import {buildGraph} from '../assets/graph-model.js';
test('imports a Claude chat export',()=>{
 const imported=parseImport('conversations.json',JSON.stringify([{uuid:'abc',name:'History ideas',chat_messages:[{sender:'human',text:'Research art'},{sender:'assistant',content:[{type:'text',text:'Try visual sources.'}]}]}]));
 assert.equal(imported.length,1);assert.equal(imported[0].type,'conversation');assert.match(imported[0].content,/Try visual sources/);
});
test('imports Markdown as notes',()=>{
 const notes=parseImport('test.md','# Great idea\nStudy #history and [[Visual art]]');assert.equal(notes[0].title,'Great idea');assert.deepEqual(notes[0].tags,['history']);
});
test('backup round-trips',()=>{
 const note=normalizeNote({title:'A',content:'safe',tags:['AI','#Design']});const backup=makeBackup([note]);assert.deepEqual(validateHive(JSON.parse(JSON.stringify(backup))).nodes,[note]);
});
test('invalid backups are rejected',()=>{assert.throws(()=>validateHive({nodes:[]}));});
test('graph contains topic and wiki links',()=>{
 const model=buildGraph(SAMPLE);assert.ok(model.nodes.some(n=>n.id==='tag:design'));assert.ok(model.edges.some(e=>e.kind==='wikilink'));assert.ok(model.topics>0);
});
test('search and filters work',()=>{
 const model=buildGraph(SAMPLE,'ai','Knowledge graphs');assert.ok(model.thoughts>=1);assert.ok(model.nodes.some(n=>n.label==='Knowledge graphs'));
});
test('limits graph node simulation cost',()=>{
 const lots=Array.from({length:400},(_,i)=>normalizeNote({id:String(i),title:'Item '+i,content:'',tags:[]}));assert.equal(buildGraph(lots).thoughts,200);
});
