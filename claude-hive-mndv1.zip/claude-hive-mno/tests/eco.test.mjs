import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,readFile,mkdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
import {condenseLog,eligibleCommand,packHive,proxyTokens} from '../scripts/eco-core.mjs';
const longSuccess=Array.from({length:450},(_,i)=>`✓ module-${i.toString().padStart(3,'0')}.test.js successful`).join('\n')+'\nTests: 450 passed, 450 total\nTime: 1.42 s\n';
const good={mode:'balanced',command:'npm test',stderr:''};

test('reduces huge successful test output while retaining pass summary',()=>{
 const r=condenseLog(longSuccess,good);
 assert.equal(r.changed,true);
 assert.ok(r.output.includes('450 passed'));
 assert.ok(r.output.length/longSuccess.length<0.25);
 assert.match(r.output,/re-run/i);
});
test('respects mode, short output, unsupported and risky chained commands',()=>{
 assert.equal(condenseLog(longSuccess,{...good,mode:'off'}).changed,false);
 assert.equal(condenseLog('ok',{...good}).changed,false);
 assert.equal(condenseLog(longSuccess,{...good,command:'cat secrets.txt'}).changed,false);
 assert.equal(eligibleCommand('npm test && rm -rf foo'),false);
 assert.equal(eligibleCommand('npm test; echo something'),false);
 assert.equal(eligibleCommand('pytest -q'),true);
});
test('preserves all diagnostics including stdout failures, stderr and interrupt',()=>{
 assert.equal(condenseLog(longSuccess+'\nError: bad input',good).changed,false);
 assert.equal(condenseLog(longSuccess+'\nWARNING: deprecated API',good).changed,false);
 assert.equal(condenseLog(longSuccess,{...good,stderr:'warning: potential issue'}).changed,false);
 assert.equal(condenseLog(longSuccess,{...good,interrupted:true}).changed,false);
 assert.equal(condenseLog(longSuccess,{...good,isImage:true}).changed,false);
});
test('does not over-compress already short logs',()=>{
 const log=Array.from({length:3},()=> 'result ok').join('\n');
 assert.equal(condenseLog(log,good).output,log);
});
const hives=[
 {id:'wiki',title:'Knowledge Graphs',tags:['graphs','encyclopedia'],content:'Source: https://en.wikipedia.org/wiki/Knowledge_graph\nRetrieved: 2026-11-15\n\nKnowledge graphs represent entities and relationships as nodes and edges. Citation and provenance matter for trustworthy retrieval.'},
 {id:'pic',title:'Mountains',tags:['photography'],content:'Photograph of an alpine landscape with snowy mountains and clear sky.'},
 {id:'dup',title:'Second Copy',tags:[],content:'Source: https://en.wikipedia.org/wiki/Knowledge_graph\nRetrieved: 2026-11-15\n\nKnowledge graphs represent entities and relationships as nodes and edges. Citation and provenance matter for trustworthy retrieval.'},
 ...Array.from({length:48},(_,i)=>({id:`distractor-${i}`,title:`Build log ${i}`,tags:['build'],content:('Compiler optimizations and bundle summaries. ').repeat(60)}))
];
test('selects relevant content with source provenance and line numbers',()=>{
 const r=packHive(hives,'knowledge graph relationships',{budget:400});
 assert.ok(r.selected.some(s=>s.id==='wiki'));
 assert.match(r.text,/en.wikipedia.org\/wiki\/Knowledge_graph/);
 assert.match(r.text,/L1-/);
 assert.match(r.text,/nodes and edges/);
 assert.ok(proxyTokens(r.text)<=400);
 assert.doesNotMatch(r.text,/alpine landscape/);
});
test('keeps context under budget and does not replicate duplicate content',()=>{
 const r=packHive(hives,'relationships',{budget:160});
 assert.ok(r.text.length<=640);
 assert.ok(r.selected.length<=1);
 assert.throws(()=>packHive(hives,'',{budget:160}),/meaningful/);
 assert.throws(()=>packHive(hives,'relationships',{budget:5}),/Budget/);
});
test('works with empty vault and no matches',()=>{
 const r=packHive([],'graph topology',{budget:200});
 assert.equal(r.selected.length,0);
 assert.match(r.text,/No relevant/);
});
test('actual hook returns valid output shape only when local opt-in enabled',async()=>{
 const root=await mkdtemp(join(tmpdir(),'hive-eco-tests-'));
 const hook=resolve('hooks/eco-hook.mjs');
 const input={cwd:root,hook_event_name:'PostToolUse',tool_name:'Bash',tool_input:{command:'npm test'},tool_response:{stdout:longSuccess,stderr:'',interrupted:false,isImage:false}};
 const run=()=>spawnSync('node',[hook,'post-tool'],{input:JSON.stringify(input),encoding:'utf8',timeout:5000});
 assert.equal(run().stdout.trim(),'');
 await mkdir(join(root,'.claude'));await writeFile(join(root,'.claude','hive-eco.json'),JSON.stringify({enabled:true,mode:'balanced'}));
 const active=run();assert.equal(active.status,0);const output=JSON.parse(active.stdout);
 assert.equal(output.hookSpecificOutput.hookEventName,'PostToolUse');
 assert.equal(output.hookSpecificOutput.updatedToolOutput.stderr,'');
 assert.ok(output.hookSpecificOutput.updatedToolOutput.stdout.length<longSuccess.length);
 const lines=(await readFile(join(root,'.claude','hive-eco-usage.jsonl'),'utf8')).trim().split('\n');
 assert.equal(lines.length,1);assert.ok(JSON.parse(lines[0]).rawProxyTokens>JSON.parse(lines[0]).keptProxyTokens);
 input.tool_response.stderr='warning';assert.equal(run().stdout.trim(),'');
});
