import test from 'node:test';
import assert from 'node:assert/strict';
import {validateForumUrl,extractForum,importForum} from '../scripts/forum-sources.mjs';
const resolveAddresses=async()=>[{address:'8.8.8.8',family:4}];
test('generic public forum URLs accepted',async()=>{
 const u=await validateForumUrl('https://discuss.example.org/t/help',resolveAddresses);
 assert.equal(u.hostname,'discuss.example.org');
});
test('local/private addresses rejected',async()=>{
 await assert.rejects(()=>validateForumUrl('https://example.org/',async()=>[{address:'127.0.0.1',family:4}]));
 await assert.rejects(()=>validateForumUrl('http://example.org/',resolveAddresses));
});
test('forum content strips navigation and scripts',()=>{
 const r=extractForum('<html><head><title>Bug discussion</title></head><body><nav>irrelevant</nav><main><article><p>Fix the compiler warning by updating the dependency versions and rebuilding the application.</p></article></main><script>secret()</script></body></html>','https://example.org/t/1');
 assert.match(r.text,/compiler warning/);assert.doesNotMatch(r.text,/irrelevant|secret/);
});
test('single link imports as knowledge node',async()=>{
 const request=async()=>({ok:true,headers:new Headers({'content-type':'text/html'}),body:null,text:async()=>'<title>Forum thread</title><main>How to resolve a broken build in the sample project. Check the package manager configuration.</main>'});
 const n=await importForum('https://forum.example.org/topic/1',{request,resolveAddresses});
 assert.ok(n.tags.includes('forum'));assert.match(n.content,/Source: https:\/\/forum.example.org/);
});
test('redirects are blocked',async()=>{
 let opt;
 const request=async(_,options)=>{opt=options;throw Error('redirect refused')};
 await assert.rejects(()=>importForum('https://example.org',{request,resolveAddresses}));
 assert.equal(opt.redirect,'error');
});
