import test from 'node:test';import assert from 'node:assert/strict';import {safePublicUrl,htmlToText,makeNode} from '../scripts/knowledge-sources.mjs';
test('accepts public HTTPS',()=>assert.equal(safePublicUrl('https://en.wikipedia.org/wiki/Graph').hostname,'en.wikipedia.org'));
test('blocks local, HTTP and IP',()=>{for(const u of ['http://example.com','https://localhost/x','https://127.0.0.1/x','https://user:pass@example.com'])assert.throws(()=>safePublicUrl(u));});
test('strips script and HTML',()=>assert.equal(htmlToText('<h1>Title</h1><script>bad()</script><p>A &amp; B</p>'),'Title A & B'));
test('makes Hive-compatible notes',()=>{const n=makeNode({title:'Source',content:'Facts',sourceUrl:'https://example.com'});assert.equal(n.title,'Source');assert.match(n.content,/Source: https:/);});
