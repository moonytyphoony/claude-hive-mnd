import test from 'node:test';
import assert from 'node:assert/strict';
import {CloudManager} from '../assets/cloud.js';

test('OneDrive uses dedicated app folder and handles a nonexistent backup',async()=>{
 const manager=new CloudManager();manager.tokens.onedrive='mock';const actual=[];const original=globalThis.fetch;
 globalThis.fetch=async(url,opts)=>{actual.push({url,opts});return {status:404,ok:false};};
 try{assert.equal(await manager.pullOneDrive(),null);assert.match(actual[0].url,/special\/approot:\/claude-hive\.json:\/content/);assert.equal(actual[0].opts.headers.Authorization,'Bearer mock');}finally{globalThis.fetch=original;}
});
test('Dropbox writes to its app folder with overwrite mode',async()=>{
 const manager=new CloudManager();manager.tokens.dropbox='mock';const original=globalThis.fetch;let req;
 globalThis.fetch=async(url,opts)=>{req={url,opts};return{ok:true,status:200};};
 try{await manager.pushDropbox('{"version":1}');assert.match(req.url,/files\/upload$/);assert.deepEqual(JSON.parse(req.opts.headers['Dropbox-API-Arg']),{path:'/claude-hive.json',mode:'overwrite',autorename:false,mute:true});}finally{globalThis.fetch=original;}
});
test('Google Drive app data list limits space',async()=>{
 const manager=new CloudManager();manager.tokens.google='mock';const original=globalThis.fetch;let path;
 globalThis.fetch=async(url)=>{path=url;return{ok:true,json:async()=>({files:[]})};};
 try{assert.equal(await manager.googleFileId(),null);const url=new URL(path);assert.equal(url.searchParams.get('spaces'),'appDataFolder');assert.equal(url.searchParams.get('pageSize'),'100');}finally{globalThis.fetch=original;}
});
