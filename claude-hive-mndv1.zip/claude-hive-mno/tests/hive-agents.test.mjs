import test from 'node:test';
import assert from 'node:assert/strict';
import {validateManifest,mapLimit,processBatch,promptFor} from '../scripts/hive-agents.mjs';
test('requires transcript for YouTube',()=>assert.throws(()=>validateManifest({sources:[{type:'youtube',url:'https://youtube.com/watch?v=abcdefghijk'}]})));
test('bounded parallelism and input order',async()=>{
 let active=0,peak=0;const result=await mapLimit([0,1,2,3,4],2,async n=>{active++;peak=Math.max(active,peak);await new Promise(r=>setTimeout(r,8*(5-n)));active--;return n*n});
 assert.ok(peak<=2);assert.deepEqual(result.map(r=>r.value),[0,1,4,9,16]);
});
test('parallel research isolates failed sources',async()=>{
 const batch=await processBatch({sources:[{type:'text',url:'a'},{type:'text',url:'b'}]},{agents:2,loader:async s=>{if(s.url==='b')throw Error('broken');return {title:'a',content:'text'}}});
 assert.equal(batch.success,1);assert.equal(batch.failed,1);
});
test('independent analysis generates second node',async()=>{
 const batch=await processBatch({sources:[{type:'text',url:'a'}]},{analyze:true,loader:async()=>({id:'x',title:'A',content:'Source: https://example.com'}),analyzer:async()=> 'Summary with uncertainty'});
 assert.match(batch.results[0].value.analysis.content,/Summary with uncertainty/);
 assert.match(promptFor(batch.results[0].value.node),/untrusted SOURCE DATA/);
});
