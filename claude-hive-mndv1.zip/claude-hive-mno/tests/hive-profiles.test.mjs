import test from 'node:test';
import assert from 'node:assert/strict';
import {makePublicProfile,parsePublicProfile,profileToMarkdown} from '../assets/hive-profiles.js';
test('profile roundtrip',()=>{
 const p=makePublicProfile({name:'Researcher',tone:'precise',instructions:['Cite sources'],sources:[{type:'forum',url:'https://example.org/thread',title:'Help'}]});
 assert.deepEqual(parsePublicProfile(JSON.stringify(p)),p);
 assert.match(profileToMarkdown(p),/Cite sources/);
});
test('no cloud secrets or private notes in public schema',()=>{
 const p=makePublicProfile({name:'Dev',token:'secret',notes:[{content:'private'}],sources:[{type:'text',url:'/home/me/private.txt'},{type:'web',url:'https://example.org'}]});
 assert.doesNotMatch(JSON.stringify(p),/secret|private/);
 assert.equal(p.sources.length,1);
});
test('bad profile rejected',()=>assert.throws(()=>parsePublicProfile('{"format":"bad"}')));
test('agent count clamped',()=>assert.equal(makePublicProfile({name:'Dev',maxAgents:999}).settings.maxAgents,8));
test('reject non https source',()=>assert.equal(makePublicProfile({name:'Dev',sources:[{type:'web',url:'http://example.org'}]}).sources.length,0));
