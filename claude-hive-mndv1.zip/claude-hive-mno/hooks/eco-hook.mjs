#!/usr/bin/env node
/** Claude Code hook. Fail open: an optimizer must never break tool execution. */
import {readFile,appendFile} from 'node:fs/promises';
import {join} from 'node:path';
import {condenseLog,proxyTokens} from '../scripts/eco-core.mjs';

async function stdinJSON(){
  let data='';
  for await(const part of process.stdin){
    data+=part;
    if(data.length>5_500_000)return null;
  }
  try{return JSON.parse(data);}catch{return null;}
}
async function main(){
  const event=process.argv[2];
  const input=await stdinJSON();
  if(!input||!input.cwd||typeof input.cwd!=='string')return;
  const root=input.cwd;
  let cfg;
  try{cfg=JSON.parse(await readFile(join(root,'.claude','hive-eco.json'),'utf8'));}catch{return;}
  if(cfg?.enabled!==true || !['balanced','max'].includes(cfg.mode))return;
  if(event==='session'){
    const context='Claude Hive ECO is enabled. Successful long test/build Bash outputs may be abridged; always inspect full output if needed. For research, use the hive-eco skill to retrieve only relevant source excerpts with citations. Keep security checks, error handling, tests and accessibility intact.';
    console.log(JSON.stringify({hookSpecificOutput:{hookEventName:'SessionStart',additionalContext:context}}));
    return;
  }
  if(event!=='post-tool'||input.tool_name!=='Bash')return;
  const response=input.tool_response;
  if(!response || typeof response!=='object'||Array.isArray(response)||typeof response.stdout!=='string')return;
  const result=condenseLog(response.stdout,{mode:cfg.mode,command:input.tool_input?.command,stderr:response.stderr,interrupted:response.interrupted,isImage:response.isImage});
  if(!result.changed)return;
  console.log(JSON.stringify({hookSpecificOutput:{hookEventName:'PostToolUse',updatedToolOutput:{...response,stdout:result.output}}}));
  // Only usage counts (never commands or tool content) are written locally.
  try{
    const record={at:new Date().toISOString(),mode:cfg.mode,rawChars:result.originalChars,keptChars:result.resultChars,
      rawProxyTokens:proxyTokens(response.stdout),keptProxyTokens:proxyTokens(result.output)};
    await appendFile(join(root,'.claude','hive-eco-usage.jsonl'),JSON.stringify(record)+'\n',{mode:0o600});
  }catch{/* No stats is better than interrupting Claude. */}
}
main().catch(()=>{});
