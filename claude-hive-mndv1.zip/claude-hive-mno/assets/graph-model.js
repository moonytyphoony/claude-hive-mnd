const canonical = t => String(t).trim().toLocaleLowerCase();
export function buildGraph(notes, filterTag = '', search = '') {
  const query=canonical(search);const searchMatch=n=>!query||`${n.title} ${n.content} ${n.tags.join(' ')}`.toLocaleLowerCase().includes(query);
  const matches=notes.filter(n=>(!filterTag || n.tags.includes(filterTag)) && searchMatch(n)).slice(0,200); // Bound force simulation cost; search narrows larger vaults.
  const nodes=matches.map(n=>({id:n.id,label:n.title,kind:n.type==='conversation'?'conversation':'note',note:n,weight:1}));
  const tagCounts=new Map(); for(const n of matches) for(const tag of n.tags) tagCounts.set(tag,(tagCounts.get(tag)||0)+1);
  const tags=[...tagCounts].sort((a,b)=>b[1]-a[1]).slice(0,22);
  for(const [tag,weight] of tags) nodes.push({id:`tag:${tag}`,label:tag,kind:'topic',weight});
  const tagSet=new Set(tags.map(x=>x[0]));const edges=[];const added=new Set();
  function link(a,b,kind){if(a===b)return;const key=[a,b].sort().join('!');if(added.has(key))return;added.add(key);edges.push({source:a,target:b,kind});}
  for (const n of matches) for(const tag of n.tags) if(tagSet.has(tag))link(n.id,`tag:${tag}`,'tag');
  const index=new Map(matches.map(n=>[canonical(n.title),n.id]));
  for(const n of matches) for(const found of n.content.matchAll(/\[\[([^\]]{1,140})\]\]/g)){const target=index.get(canonical(found[1]));if(target)link(n.id,target,'wikilink');}
  return {nodes,edges,thoughts:matches.length,topics:tags.length};
}
