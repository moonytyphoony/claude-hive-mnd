/* Claude Hive: browser-only, opt-in storage adapters.
   Public OAuth app identifiers may be saved locally; access tokens/passwords never are. */
const TOKEN_FILE = 'claude-hive.json';
const CLIENT_KEY='claude-hive:oauth-clients';
const OAUTH_PENDING='claude-hive:oauth-pending';
const MS_SCOPE='Files.ReadWrite.AppFolder'; // OneDrive Personal only
const DROPBOX_SCOPES='files.content.read files.content.write';
function redirectUri(){return `${location.origin}${location.pathname}`;}
function randomString(){const bytes=crypto.getRandomValues(new Uint8Array(32));return [...bytes].map(n=>n.toString(16).padStart(2,'0')).join('');}
function base64Url(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
async function challenge(verifier){return base64Url(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)));}
async function request(url,opts={}) { const r=await fetch(url,opts);if(!r.ok){let body=await r.text().catch(()=>r.statusText);let message=body.slice(0,350);try{const parsed=JSON.parse(body);message=parsed.error?.message||parsed.error_summary||parsed.error_description||message;}catch{}throw new Error(`${r.status}: ${message}`);}return r; }
async function jsonRequest(url,opts){return (await request(url,opts)).json();}
function bearer(token){return {Authorization:`Bearer ${token}`};}
function codeToken(url,body){return jsonRequest(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(body)});}
export class CloudManager {
  constructor(onUpdate){this.onUpdate=onUpdate||(()=>{});this.tokens={};this.mega=null;let saved={};try{saved=JSON.parse(localStorage.getItem(CLIENT_KEY)||'{}');}catch{}this.clients=saved;}
  getClient(provider){return this.clients[provider]||'';}
  setClient(provider,val){this.clients[provider]=String(val||'').trim();localStorage.setItem(CLIENT_KEY,JSON.stringify(this.clients));}
  connected(p){return p==='mega'?Boolean(this.mega):Boolean(this.tokens[p]);}
  isAnyConnected(){return ['google','onedrive','dropbox','mega'].some(x=>this.connected(x));}
  update(){this.onUpdate();}
  async completeRedirect(){const params=new URLSearchParams(location.search);const code=params.get('code'),error=params.get('error');const pendingRaw=sessionStorage.getItem(OAUTH_PENDING);if(!code&&!error)return null;
    // Only process callbacks we started, to prevent stealing unrelated query parameters.
    if(!pendingRaw)return null;
    const pending=JSON.parse(pendingRaw);sessionStorage.removeItem(OAUTH_PENDING);
    // Strip auth code immediately from address bar even on errors.
    history.replaceState({},document.title,redirectUri()+location.hash);
    if(params.get('state')!==pending.state)throw new Error('OAuth state mismatch. Please connect again.');
    if(error)throw new Error(`Authentication declined: ${error}`);
    if(!code)throw new Error('Missing OAuth code');
    const tokenBody={grant_type:'authorization_code',code,client_id:pending.clientId,redirect_uri:redirectUri(),code_verifier:pending.verifier};
    let result;
    if(pending.provider==='onedrive')result=await codeToken('https://login.microsoftonline.com/consumers/oauth2/v2.0/token',{...tokenBody,scope:MS_SCOPE});
    else if(pending.provider==='dropbox')result=await codeToken('https://api.dropboxapi.com/oauth2/token',tokenBody);
    else throw new Error('Unknown OAuth callback');
    if(!result.access_token)throw new Error('No access token returned');
    this.tokens[pending.provider]=result.access_token;this.update();return pending.provider;
  }
  async connect(provider,megaInfo){
    if(provider==='mega')return this.connectMega(megaInfo);
    const clientId=this.getClient(provider);if(!clientId)throw new Error('First enter your public OAuth app/client ID');
    if(provider==='google'){
      if(!window.google?.accounts?.oauth2)throw new Error('Google identity script is unavailable. Check your connection or blockers.');
      const token=await new Promise((resolve,reject)=>{
        const client=window.google.accounts.oauth2.initTokenClient({client_id:clientId,scope:'https://www.googleapis.com/auth/drive.appdata',callback:response=>response.error?reject(new Error(response.error)):resolve(response.access_token),error_callback:()=>reject(new Error('Google sign-in popup could not open'))});
        client.requestAccessToken({prompt:'consent'});
      });
      this.tokens.google=token;this.update();return;
    }
    if(!['onedrive','dropbox'].includes(provider))throw new Error('Unknown provider');
    const verifier=randomString(),state=randomString();const q=await challenge(verifier);
    sessionStorage.setItem(OAUTH_PENDING,JSON.stringify({provider,verifier,state,clientId}));
    const url=new URL(provider==='onedrive'?'https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize':'https://www.dropbox.com/oauth2/authorize');
    if(provider==='onedrive')Object.entries({client_id:clientId,response_type:'code',redirect_uri:redirectUri(),scope:MS_SCOPE,code_challenge:q,code_challenge_method:'S256',state,response_mode:'query'}).forEach(([k,v])=>url.searchParams.set(k,v));
    else Object.entries({client_id:clientId,response_type:'code',redirect_uri:redirectUri(),token_access_type:'online',scope:DROPBOX_SCOPES,code_challenge:q,code_challenge_method:'S256',state}).forEach(([k,v])=>url.searchParams.set(k,v));
    location.assign(url.toString());
  }
  async connectMega({email,password,secondFactorCode}={}){
    if(!email||!password)throw new Error('Enter your MEGA email and password');
    // A pinned unofficial browser SDK. Never send credentials to our own server.
    const {Storage}=await import('https://unpkg.com/megajs@1.3.10/dist/main.browser-es.mjs');
    const options={email,password,keepalive:false,userAgent:null};if(secondFactorCode)options.secondFactorCode=secondFactorCode;
    const s=await new Storage(options).ready;this.mega=s;this.update();
  }
  async disconnect(p){
    if(p==='mega'){try{await this.mega?.close();}catch{}this.mega=null;}
    else {if(p==='google'&&this.tokens.google&&window.google?.accounts?.oauth2?.revoke){window.google.accounts.oauth2.revoke(this.tokens.google,()=>{});}delete this.tokens[p];}
    this.update();
  }
  token(p){const token=this.tokens[p];if(!token)throw new Error(`Connect ${p} before syncing`);return token;}
  async pull(p){
    let raw;
    if(p==='google')raw=await this.pullGoogle();
    else if(p==='onedrive')raw=await this.pullOneDrive();
    else if(p==='dropbox')raw=await this.pullDropbox();
    else if(p==='mega')raw=await this.pullMega();
    else throw new Error('Unknown provider');
    if(!raw)return null;
    if(raw.length>30_000_000)throw new Error('Cloud backup is too large');
    return JSON.parse(raw);
  }
  async push(p,backup){const raw=JSON.stringify(backup);if(p==='google')return this.pushGoogle(raw);if(p==='onedrive')return this.pushOneDrive(raw);if(p==='dropbox')return this.pushDropbox(raw);if(p==='mega')return this.pushMega(raw);throw new Error('Unknown provider');}
  async googleFileId(){const query=new URLSearchParams({spaces:'appDataFolder',q:`name = '${TOKEN_FILE}' and trashed = false`,fields:'nextPageToken,files(id,name)',pageSize:'100'});const list=await jsonRequest(`https://www.googleapis.com/drive/v3/files?${query}`,{headers:bearer(this.token('google'))});return list.files?.[0]?.id||null;}
  async pullGoogle(){const id=await this.googleFileId();if(!id)return null;return (await request(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(id)}?alt=media`,{headers:bearer(this.token('google'))})).text();}
  async pushGoogle(raw){const id=await this.googleFileId();const token=this.token('google');if(id){await request(`https://www.googleapis.com/upload/drive/v3/files/${encodeURIComponent(id)}?uploadType=media`,{method:'PATCH',headers:{...bearer(token),'Content-Type':'application/json'},body:raw});return;}
    const boundary=`hive_${randomString()}`;const metadata=JSON.stringify({name:TOKEN_FILE,parents:['appDataFolder'],mimeType:'application/json'});
    const body=`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${raw}\r\n--${boundary}--`;
    await request('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',{method:'POST',headers:{...bearer(token),'Content-Type':`multipart/related; boundary=${boundary}`},body});
  }
  onedriveUrl(){return `https://graph.microsoft.com/v1.0/me/drive/special/approot:/${TOKEN_FILE}:/content`;}
  async pullOneDrive(){const r=await fetch(this.onedriveUrl(),{headers:bearer(this.token('onedrive'))});if(r.status===404)return null;if(!r.ok)throw new Error(`OneDrive ${r.status}: ${await r.text().then(x=>x.slice(0,250))}`);return r.text();}
  async pushOneDrive(raw){await request(this.onedriveUrl(),{method:'PUT',headers:{...bearer(this.token('onedrive')),'Content-Type':'application/json'},body:raw});}
  async pullDropbox(){const r=await fetch('https://content.dropboxapi.com/2/files/download',{method:'POST',headers:{...bearer(this.token('dropbox')),'Dropbox-API-Arg':JSON.stringify({path:`/${TOKEN_FILE}`})}});if(r.status===409){const details=await r.text();if(details.includes('not_found'))return null;throw new Error(`Dropbox 409: ${details.slice(0,200)}`);}if(!r.ok)throw new Error(`Dropbox ${r.status}: ${await r.text().then(x=>x.slice(0,250))}`);return r.text();}
  async pushDropbox(raw){await request('https://content.dropboxapi.com/2/files/upload',{method:'POST',headers:{...bearer(this.token('dropbox')),'Content-Type':'application/octet-stream','Dropbox-API-Arg':JSON.stringify({path:`/${TOKEN_FILE}`,mode:'overwrite',autorename:false,mute:true})},body:raw});}
  async megaFolder(){if(!this.mega)throw new Error('Connect MEGA first');let folder=this.mega.root.children.find(n=>n.directory&&n.name==='Claude Hive');if(!folder)folder=await this.mega.root.mkdir('Claude Hive');return folder;}
  async pullMega(){const folder=await this.megaFolder();const f=folder.children.find(n=>!n.directory&&n.name===TOKEN_FILE);if(!f)return null;const buffer=await f.downloadBuffer();return new TextDecoder().decode(buffer);}
  async pushMega(raw){const folder=await this.megaFolder();const old=folder.children.find(n=>!n.directory&&n.name===TOKEN_FILE);const temp=await folder.upload(`claude-hive-${Date.now()}.json`,raw).complete; // preserve old backup until upload succeeds
    if(old)await old.delete();await temp.rename(TOKEN_FILE);
  }
}
