import {SAMPLE,loadLocal,saveLocal,normalizeNote,uid,cleanTags,makeBackup,validateHive,parseImport} from './data.js';
import {buildGraph} from './graph-model.js';
import {HiveGraph} from './graph.js';
import {CloudManager} from './cloud.js';
import {makePublicProfile,parsePublicProfile} from './hive-profiles.js';
const $=id=>document.getElementById(id);const $$=query=>[...document.querySelectorAll(query)];
let local=loadLocal(),isDemo=local===null,notes=local??SAMPLE,view='graph',filterTag='',search='',selectedId=null,editId=null,toastTimer;
const graph=new HiveGraph($('graph-canvas'),{onSelect:node=>openDetail(node.id)});
const cloud=new CloudManager(updateCloudUi);
const providers=['google','onedrive','dropbox','mega'];
function notice(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),4500);}
function safeSave(){try{saveLocal(notes);isDemo=false;}catch(error){notice('Could not save to browser: '+error.message);}}
function el(tag,className,text){const e=document.createElement(tag);if(className)e.className=className;if(text!==undefined)e.textContent=text;return e;}
function connectedLabel(){return providers.filter(x=>cloud.connected(x)).length;}
function updateCloudUi(){for(const p of providers){const connected=cloud.connected(p);const status=$(`status-${p}`);status.textContent=connected?'Connected':'Disconnected';status.classList.toggle('connected',connected);$$(`[data-pull="${p}"], [data-push="${p}"], [data-disconnect="${p}"]`).forEach(b=>b.disabled=!connected);const connect=document.querySelector(`[data-connect="${p}"]`);connect.disabled=connected;}
  const count=connectedLabel();$('cloud-summary').textContent=count?`${count} provider${count>1?'s':''} connected`:'Not connected';$('stat-sync').textContent=count?`${count} cloud`:'Local';}
function renderTags(){const count=new Map();for(const n of notes)for(const tag of n.tags)count.set(tag,(count.get(tag)||0)+1);const host=$('tag-list');host.replaceChildren();for(const [tag,n] of [...count].sort((a,b)=>b[1]-a[1]).slice(0,17)){const b=el('button','tag-filter'+(filterTag===tag?' active':''));b.append(el('span','',`# ${tag}`),el('b','',n));b.onclick=()=>{filterTag=filterTag===tag?'':tag;render();};host.append(b);} }
function showView(next){view=next;$('graph-stage').hidden=next!=='graph';$('notes-stage').hidden=next!=='notes';$('view-name').textContent=next==='graph'?'KNOWLEDGE GRAPH':'ALL THOUGHTS';$('main-title').textContent=next==='graph'?'Your idea universe.':'Every thought, one place.';$('main-subtitle').textContent=next==='graph'?'Explore the connections between conversations, notes and insights.':'Search and revisit all the things worth keeping.';$('nav-graph').classList.toggle('active',next==='graph');$('nav-notes').classList.toggle('active',next==='notes');if(next==='graph')graph.resize();}
function render(){const model=buildGraph(notes,filterTag,search);graph.setData(model);$('node-count').textContent=notes.length;$('notes-count').textContent=notes.length;$('stat-nodes').textContent=notes.length;$('stat-links').textContent=model.edges.length;$('stat-clusters').textContent=new Set(notes.flatMap(n=>n.tags)).size;$('data-kind').textContent=isDemo?'SAMPLE':'PRIVATE';$('data-kind').style.color=isDemo?'#f0c78e':'#84e5d1';$('graph-empty').hidden=model.nodes.length>0;renderTags();renderNotes(model);if(selectedId && !model.nodes.find(n=>n.id===selectedId))clearDetail();else if(selectedId)openDetail(selectedId,false);updateCloudUi();}
function renderNotes(model){const grid=$('notes-grid');grid.replaceChildren();const visible=model.nodes.filter(n=>n.note);$('thought-count').textContent=`${visible.length} item${visible.length===1?'':'s'}`;if(!visible.length){grid.append(el('p','notes-empty','No thoughts match this filter.'));return;}for(const entry of visible){const n=entry.note;const btn=el('button','note-card');btn.append(el('span','',n.type==='conversation'?'◉ CLAUDE CONVERSATION':'⬡ NOTE'),el('strong','',n.title),el('small','',n.content.slice(0,145)||(n.tags.join(', ')||'No content yet')));btn.onclick=()=>openDetail(n.id);grid.append(btn);}}
function clearDetail(){selectedId=null;graph.select(null);$('edit-note').disabled=true;$('detail-inner').replaceChildren();const div=el('div','detail-placeholder');div.append(el('div','ph-orbit','⬡'),el('h3','','Follow an idea'),el('p','','Click any node to open its details and explore what connects to it.'));$('detail-inner').append(div);$('detail-panel').classList.remove('open');}
function openDetail(id,popup=true){selectedId=id;graph.select(id);$('detail-inner').replaceChildren();const host=$('detail-inner');const note=notes.find(n=>n.id===id);const m=buildGraph(notes,filterTag,search);const relatedIds=m.edges.filter(e=>e.source===id||e.target===id).map(e=>e.source===id?e.target:e.source).filter(x=>x!==id);const related=m.nodes.filter(n=>relatedIds.includes(n.id));$('edit-note').disabled=!note;host.append(el('span','detail-type',note?(note.type==='conversation'?'Claude conversation':'Note'):'Topic cluster'),el('h2','detail-title',note?.title||id.replace('tag:','# ')));
  if(note){host.append(el('p','detail-date',`Updated ${new Date(note.updatedAt).toLocaleDateString()}`),el('p','detail-copy',note.content||'No additional notes yet.'));if(note.tags.length){const tags=el('div','detail-tags');for(const tag of note.tags)tags.append(el('span','',`#${tag}`));host.append(tags);}}
  else host.append(el('p','detail-copy','A topic that connects several of your thoughts.'));
  host.append(el('div','related-heading',`${related.length} CONNECTED NODES`));for(const n of related.slice(0,18)){const b=el('button','related-link',`${n.kind==='topic'?'◈': '⬡'}  ${n.label}`);b.onclick=()=>openDetail(n.id);host.append(b);}
  if(popup && window.innerWidth<=1100)$('detail-panel').classList.add('open');}
function openModal(id){$(id).hidden=false;document.body.style.overflow='hidden';}
function closeModal(id){$(id).hidden=true;if($$('.modal-overlay:not([hidden])').length===0)document.body.style.overflow='';}
function newEditor(note=null){editId=note?.id||null;$('editor-title').textContent=note?'Edit thought':'New thought';$('note-title').value=note?.title||'';$('note-tags').value=note?.tags.join(', ')||'';$('note-content').value=note?.content||'';$('delete-note').hidden=!note;openModal('editor-modal');$('note-title').focus();}
function addNoteFromEditor(e){e.preventDefault();const title=$('note-title').value.trim(),content=$('note-content').value,tags=cleanTags($('note-tags').value);if(!title)return;const old=notes.find(n=>n.id===editId);const note=normalizeNote({id:editId||uid(),title,content,tags,type:old?.type||'note',createdAt:old?.createdAt,updatedAt:new Date().toISOString()});if(isDemo){notes=[];isDemo=false;filterTag='';search='';$('search').value='';}
  if(editId){const i=notes.findIndex(n=>n.id===editId);if(i>=0)notes[i]=note;else notes.push(note);}else notes.push(note);
  safeSave();closeModal('editor-modal');render();openDetail(note.id);notice('Thought saved in your browser');}
async function importFiles(files){const imported=[];const errors=[];for(const file of files){try{if(file.size>30_000_000)throw new Error('Max file size is 30 MB');const parsed=parseImport(file.name,await file.text());imported.push(...parsed);}catch(err){errors.push(`${file.name}: ${err.message}`);}}
  if(imported.length){if(isDemo){notes=[];isDemo=false;}const ids=new Set(notes.map(n=>n.id));for(const note of imported){if(ids.has(note.id))note.id=uid();ids.add(note.id);notes.push(note);}if(notes.length>15000){notes=notes.slice(0,15000);errors.push('Only the first 15,000 thoughts were kept');}filterTag='';search='';$('search').value='';safeSave();render();notice(`${imported.length} thought${imported.length===1?'':'s'} imported`);}
  if(errors.length){console.warn('Import errors',errors);notice(errors.slice(0,2).join(' · '));}}
function download(){const backup=makeBackup(isDemo?[]:notes);const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=el('a');a.href=url;a.download=`claude-hive-${new Date().toISOString().slice(0,10)}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2500);notice('Your Hive backup was downloaded');}
function downloadProfile(){
 const name=prompt('Public profile name (no private notes will be included):','My Claude Hive');
 if(!name)return;
 const description=prompt('Public description:','A practical Claude Code research assistant')||'';
 const tone=prompt('Personality tone:','Concise and evidence-focused')||'';
 const instructions=(prompt('Optional behavior preferences (one per line):','Cite sources when possible')||'').split('\\n').filter(Boolean);
 const profile=makePublicProfile({name,description,tone,instructions});
 const blob=new Blob([JSON.stringify(profile,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),link=el('a');
 link.href=url;link.download='claude-hive-profile.json';document.body.append(link);link.click();link.remove();
 setTimeout(()=>URL.revokeObjectURL(url),2500);
 notice('Public personality profile exported — private notes and cloud credentials excluded');
}
async function importProfile(file){
 try{
  if(file.size>256000)throw Error('Profile too large');
  const profile=parsePublicProfile(await file.text());
  const preview=`${profile.personality.name}\\n${profile.personality.description}\\nTone: ${profile.personality.tone}\\nRules: ${profile.personality.instructions.length}\\nPublic sources: ${profile.sources.length}\\n\\nImported community instructions are untrusted. Save profile locally?`;
  if(!confirm(preview))return;
  localStorage.setItem('claude-hive-community-profile',JSON.stringify(profile));
  notice(`Imported profile: ${profile.personality.name}. Preferences saved locally; not automatically executed.`);
 }catch(error){notice('Profile import failed: '+error.message)}
}
function cloudMessage(message){$('cloud-message').textContent=message;notice(message);}
async function cloudAction(provider,action,button){if(button.disabled)return;const original=button.textContent;button.disabled=true;button.textContent='Working…';try{
  if(action==='connect'){if(provider!=='mega'){cloud.setClient(provider,$(`client-${provider}`).value.trim());await cloud.connect(provider);}else{const email=$('mega-email').value,password=$('mega-password').value,secondFactorCode=$('mega-2fa').value;try{await cloud.connect('mega',{email,password,secondFactorCode});}finally{$('mega-password').value='';$('mega-2fa').value='';}}cloudMessage(`${providerName(provider)} connected`);}
  if(action==='disconnect'){await cloud.disconnect(provider);cloudMessage(`${providerName(provider)} disconnected`);}
  if(action==='pull'){const remote=await cloud.pull(provider);if(!remote){cloudMessage(`No Claude Hive backup found on ${providerName(provider)}`);return;}const restored=validateHive(remote).nodes;if(!confirm(`Load ${restored.length} thoughts from ${providerName(provider)}? This replaces your local Hive. Export first if you want a backup.`))return;notes=restored;isDemo=false;filterTag='';search='';$('search').value='';safeSave();clearDetail();render();cloudMessage(`Loaded ${restored.length} thoughts from ${providerName(provider)}`);}
  if(action==='push'){if(isDemo){cloudMessage('Import a conversation or add a thought before uploading. Sample data is not saved.');return;}const originalRemote=await cloud.pull(provider);if(originalRemote&&!confirm(`Replace the existing ${providerName(provider)} backup with your current Hive? This does not merge changes.`))return;await cloud.push(provider,makeBackup(isDemo?[]:notes));cloudMessage(`Saved ${isDemo?0:notes.length} thoughts to ${providerName(provider)}`);}
  }catch(error){console.error(`${provider} ${action} failed`,error);cloudMessage(`${providerName(provider)}: ${error.message}`);}finally{button.textContent=original;updateCloudUi();}}
function providerName(p){return {google:'Google Drive',onedrive:'OneDrive',dropbox:'Dropbox',mega:'MEGA'}[p]||p;}
$('add-note').onclick=()=>newEditor();$('empty-add').onclick=()=>newEditor();$('edit-note').onclick=()=>newEditor(notes.find(n=>n.id===selectedId));$('close-detail').onclick=()=>clearDetail();$('editor-form').onsubmit=addNoteFromEditor;
$('delete-note').onclick=()=>{if(!editId||!confirm('Delete this thought? This cannot be undone unless it is in a backup.'))return;notes=notes.filter(n=>n.id!==editId);safeSave();closeModal('editor-modal');clearDetail();render();notice('Thought deleted');};
$('nav-graph').onclick=()=>showView('graph');$('nav-notes').onclick=()=>showView('notes');$('fit-btn').onclick=()=>graph.fit();$('graph-reset').onclick=()=>graph.fit();$('zoom-in').onclick=()=>graph.zoom(1.22);$('zoom-out').onclick=()=>graph.zoom(.82);
$('import-btn').onclick=()=>$('file-input').click();$('file-input').onchange=async e=>{await importFiles(e.target.files);e.target.value='';};$('download-btn').onclick=download;$('profile-export').onclick=downloadProfile;$('profile-import').onclick=()=>$('profile-file').click();$('profile-file').onchange=async e=>{if(e.target.files?.[0])await importProfile(e.target.files[0]);e.target.value='';};
$('search').addEventListener('input',e=>{search=e.target.value.trim();render();});
$('cloud-open').onclick=$('cloud-open-top').onclick=()=>openModal('cloud-modal');
$$('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.dataset.close)));
$$('.modal-overlay').forEach(modal=>modal.addEventListener('click',e=>{if(e.target===modal)closeModal(modal.id);}));
$$('[data-connect], [data-pull], [data-push], [data-disconnect]').forEach(b=>{const action=b.dataset.connect?'connect':b.dataset.pull?'pull':b.dataset.push?'push':'disconnect';const provider=b.dataset.connect||b.dataset.pull||b.dataset.push||b.dataset.disconnect;b.addEventListener('click',()=>cloudAction(provider,action,b));});
for(const p of ['google','onedrive','dropbox'])$(`client-${p}`).value=cloud.getClient(p);
window.addEventListener('keydown',e=>{if(e.key==='Escape'){$$('.modal-overlay:not([hidden])').forEach(m=>closeModal(m.id));$('detail-panel').classList.remove('open');}if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)&&!$$('.modal-overlay:not([hidden])').length){e.preventDefault();$('search').focus();}});
// Files can be dropped directly on the graph.
$('graph-holder').addEventListener('dragover',e=>{e.preventDefault();});$('graph-holder').addEventListener('drop',e=>{e.preventDefault();if(e.dataTransfer.files?.length)importFiles(e.dataTransfer.files);});
render();showView('graph');
cloud.completeRedirect().then(provider=>{if(provider){openModal('cloud-modal');cloudMessage(`${providerName(provider)} connected. You can now load or save your Hive.`);}}).catch(err=>{openModal('cloud-modal');cloudMessage(`Cloud sign-in failed: ${err.message}`);});
