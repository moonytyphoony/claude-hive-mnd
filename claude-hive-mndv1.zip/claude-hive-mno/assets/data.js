export const STORE_KEY = 'claude-hive:v1';
const now = () => new Date().toISOString();
const stopWords = new Set('about their there where which would could should this that with from into your have will they them then than were been also some what when just more very something think need make help based conversation messages summary general work hello assistant user'.split(' '));
export function uid() { return globalThis.crypto?.randomUUID?.() || `n-${Date.now()}-${Math.random().toString(36).slice(2)}`; }
export function cleanTags(input) { return [...new Set((Array.isArray(input) ? input : String(input || '').split(/[,;]/)).map(v => String(v).trim().replace(/^#/, '').toLowerCase().replace(/[^\p{L}\p{N} _-]/gu, '').slice(0,32)).filter(Boolean))].slice(0,12); }
export function normalizeNote(input) {
  if (!input || typeof input !== 'object') throw new Error('Invalid thought object');
  const title = String(input.title || input.name || 'Untitled').trim().slice(0,140);
  const content = String(input.content || '').slice(0,250000);
  return {id:String(input.id || uid()).slice(0,100),title,content,tags:cleanTags(input.tags),type:input.type === 'conversation' ? 'conversation' : 'note',createdAt:validDate(input.createdAt),updatedAt:validDate(input.updatedAt)};
}
function validDate(s) { return typeof s === 'string' && !Number.isNaN(Date.parse(s)) ? s : now(); }
export function validateHive(json) {
  if (!json || typeof json !== 'object' || json.version !== 1 || !Array.isArray(json.nodes)) throw new Error('Not a Claude Hive v1 backup');
  if (json.nodes.length > 15000) throw new Error('Backup exceeds 15,000 thought limit');
  return {version:1,nodes:json.nodes.map(normalizeNote)};
}
export function makeBackup(notes) { return {format:'claude-hive',version:1,exportedAt:now(),nodes:notes.map(normalizeNote)}; }
export function loadLocal() { try { const saved=localStorage.getItem(STORE_KEY); return saved ? validateHive(JSON.parse(saved)).nodes : null; } catch (error) { console.warn('Could not read local hive:', error); return null; } }
export function saveLocal(notes) { localStorage.setItem(STORE_KEY,JSON.stringify(makeBackup(notes))); }
function messageText(m) {
  if (typeof m === 'string') return m;
  if (!m || typeof m !== 'object') return '';
  if (typeof m.text === 'string') return m.text;
  if (typeof m.content === 'string') return m.content;
  if (Array.isArray(m.content)) return m.content.map(messageText).filter(Boolean).join('\n');
  if (Array.isArray(m.message?.content)) return m.message.content.map(messageText).join('\n');
  return '';
}
function guesses(title, content) {
  const explicit = [...`${title} ${content.slice(0,4000)}`.matchAll(/(?:^|\s)#([\p{L}\p{N}_-]{2,32})/gu)].map(x=>x[1]);
  if (explicit.length) return cleanTags(explicit);
  const words = `${title} ${title} ${content.slice(0,1300)}`.toLowerCase().match(/[\p{L}]{4,}/gu) || [];
  const freq = new Map();for(const w of words){ if(stopWords.has(w)) continue; freq.set(w,(freq.get(w)||0)+1); }
  return [...freq].sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]);
}
function parseClaudeConversation(c) {
  const messages = Array.isArray(c.chat_messages) ? c.chat_messages : Array.isArray(c.messages) ? c.messages : [];
  const text = messages.map(m => {
    const role = m.sender || m.role || m.message?.role || 'message';
    return `${role === 'human' ? 'You' : role === 'assistant' ? 'Claude' : role}: ${messageText(m)}`;
  }).filter(s=>s.split(': ').slice(1).join(': ').trim()).join('\n\n').slice(0,250000);
  const title = String(c.name || c.title || messages[0]?.text || 'Claude conversation').slice(0,140);
  return normalizeNote({id:uid(),title,content:text,tags:guesses(title,text),type:'conversation',createdAt:c.created_at || c.createdAt,updatedAt:c.updated_at || c.updatedAt});
}
export function parseImport(filename, raw) {
  const text=String(raw); if(text.length>30000000) throw new Error('This file is too large (30 MB limit)');
  if (/\.(md|markdown|txt)$/i.test(filename)) {
    const heading=text.match(/^#\s+(.+)$/m); const title=(heading?.[1] || filename.replace(/\.[^.]+$/, '')).slice(0,140);
    return [normalizeNote({title,content:text,tags:guesses(title,text)})];
  }
  let data;try {data=JSON.parse(text);}catch{throw new Error(`${filename}: expected valid JSON, Markdown or plain text`);}
  if (data?.version === 1 && Array.isArray(data.nodes)) return validateHive(data).nodes;
  const list=Array.isArray(data) ? data : Array.isArray(data?.conversations) ? data.conversations : Array.isArray(data?.chat_messages) ? [data] : null;
  if (!list) throw new Error(`${filename}: unrecognized JSON structure`);
  if (list.length>15000) throw new Error('Too many conversations in one file');
  return list.filter(x=>x && typeof x==='object').map(c=> {
    if (c.chat_messages || c.messages) return parseClaudeConversation(c);
    if (c.title || c.name) return normalizeNote({id:uid(),title:c.title||c.name,content:typeof c.content === 'string' ? c.content : '',tags:c.tags||[]});
    return null;
  }).filter(Boolean);
}
export const SAMPLE = [
 {id:'demo-1',title:'The creative process',content:'Ideas usually emerge from exploring related concepts and finding new patterns. [[Visual storytelling]] and [[Design systems]] influence the creative process. #creativity #design',tags:['creativity','design'],type:'note'},
 {id:'demo-2',title:'Visual storytelling',content:'How do images and motion communicate meaning? Experiment with color, framing, and pacing. #design #storytelling',tags:['design','storytelling'],type:'conversation'},
 {id:'demo-3',title:'Design systems',content:'Components, spacing and design tokens help turn ideas into consistent interfaces. #design #product',tags:['design','product'],type:'note'},
 {id:'demo-4',title:'Machine learning notes',content:'Clustering and embeddings can reveal the relationships between separate ideas. [[Knowledge graphs]] #ai #research',tags:['ai','research'],type:'conversation'},
 {id:'demo-5',title:'Knowledge graphs',content:'A connected vault where each piece of knowledge is a point, and shared topics become links. #ai #research',tags:['ai','research'],type:'note'},
 {id:'demo-6',title:'Content experiments',content:'Find recurring editing patterns and experiment with creative transitions. [[Visual storytelling]] #creativity #content',tags:['creativity','content'],type:'note'},
 {id:'demo-7',title:'Product roadmap',content:'A well-designed experience should be easy to try with zero setup. [[Design systems]] #product #planning',tags:['product','planning'],type:'note'},
 {id:'demo-8',title:'Ideas worth pursuing',content:'Combine different clusters: [[Machine learning notes]], [[Content experiments]] and [[Product roadmap]]. #planning #research',tags:['planning','research'],type:'conversation'},
 {id:'demo-9',title:'An interactive archive',content:'An archive that makes unexpected connections visible and easy to explore. [[Knowledge graphs]] #ai #product',tags:['ai','product'],type:'note'}
].map(n=>normalizeNote(n));
