#!/usr/bin/env node
/** Explicit configuration, retrieval and proxy stats for Hive ECO. */
import {mkdir,readFile,writeFile,stat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {packHive,proxyTokens} from './eco-core.mjs';
const args=process.argv.slice(2);
function usage(){console.log(`Claude Hive ECO — context optimization for Claude Code
Usage:
  node scripts/hive-eco.mjs on [balanced|max]
  node scripts/hive-eco.mjs off
  node scripts/hive-eco.mjs status
  node scripts/hive-eco.mjs stats
  node scripts/hive-eco.mjs pack --input hive.json --query "your topic" --budget 1100 [--out context.md]
Notes: 'pack' estimates tokens at 4 characters per token. It does NOT query an AI model.
'On' enables PostToolUse compression for SUCCESSFUL, long, allowlisted Bash test/build output in this project.
Unrecognized tools and all diagnostics bypass compression.`);}
const dir=resolve('.claude');
const configFile=join(dir,'hive-eco.json');
const usageFile=join(dir,'hive-eco-usage.jsonl');
async function getConfig(){try{return JSON.parse(await readFile(configFile,'utf8'));}catch{return {enabled:false,mode:'off'};}}
function parseFlag(name,fallback){const i=args.indexOf(name);return i<0?fallback:args[i+1];}
async function main(){
  const action=args[0];
  if(action==='on'){
    const mode=args[1]||'balanced';if(!['balanced','max'].includes(mode))throw Error('Modes: balanced or max');
    await mkdir(dir,{recursive:true});await writeFile(configFile,JSON.stringify({enabled:true,mode},null,2)+'\n',{mode:0o600});
    console.log(`Hive ECO enabled (${mode}) in ${process.cwd()}. Only successful verbose test/build Bash output is eligible for automatic compression.`);return;
  }
  if(action==='off'){
    await mkdir(dir,{recursive:true});await writeFile(configFile,JSON.stringify({enabled:false,mode:'off'},null,2)+'\n',{mode:0o600});
    console.log('Hive ECO automatic output compression disabled.');return;
  }
  if(action==='status'){
    const cfg=await getConfig();console.log(`Hive ECO ${cfg.enabled?'enabled':'disabled'} (mode: ${cfg.mode||'off'}).`);return;
  }
  if(action==='stats'){
    let data='';try{const s=await stat(usageFile);if(s.size>10_000_000)throw Error('Stats file too large');data=await readFile(usageFile,'utf8');}catch(e){if(e.code!=='ENOENT')throw e;}
    const records=data.split('\n').filter(Boolean).flatMap(s=>{try{return [JSON.parse(s)];}catch{return [];}});
    const raw=records.reduce((n,r)=>n+(Number(r.rawProxyTokens)||0),0),kept=records.reduce((n,r)=>n+(Number(r.keptProxyTokens)||0),0);
    console.log(`Compressed results: ${records.length}\nApprox. tokens in those result bodies: ${raw} → ${kept}\nApprox. result-body reduction: ${raw?((raw-kept)/raw*100).toFixed(1):0}%\nThis is NOT total Claude API/token billing; failures and uncompressed output are not counted.`);return;
  }
  if(action==='pack'){
    const file=parseFlag('--input'),query=parseFlag('--query'),budget=Number(parseFlag('--budget','1100')),out=parseFlag('--out');
    if(!file||!query)throw Error('Pack requires --input hive.json and --query "search terms"');
    const path=resolve(file),s=await stat(path);if(s.size>32_000_000)throw Error('Hive input exceeds 32MB');
    const json=JSON.parse(await readFile(path,'utf8'));
    if(json.version!==1||!Array.isArray(json.nodes)||json.nodes.length>15000)throw Error('Expected Claude Hive v1 backup');
    const packed=packHive(json.nodes,query,{budget});
    if(out){await writeFile(resolve(out),packed.text,'utf8');console.log(`Selected ${packed.selected.length} relevant excerpts. Saved to ${out}. ${packed.proxyTokens}/${budget} approximate tokens (character proxy).`);}
    else process.stdout.write(packed.text);
    return;
  }
  usage();if(action)process.exitCode=1;
}
main().catch(e=>{console.error(`Hive ECO: ${e.message}`);process.exitCode=1;});
