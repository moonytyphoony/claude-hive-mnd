#!/usr/bin/env node
/** Opt-in source importer for Claude Code Hive. No automatic crawling. */
import {readFile,writeFile} from 'node:fs/promises';
import {basename,extname,resolve} from 'node:path';
import {randomUUID} from 'node:crypto';
import {isIP} from 'node:net';
import {importForum} from './forum-sources.mjs';
const args=process.argv.slice(2);
const [command,source,out]=args;
export function safePublicUrl(input){
 const u=new URL(input);
 const h=u.hostname.toLowerCase().replace(/\.$/,'');
 if(u.protocol!=='https:'||u.username||u.password||u.port||isIP(h)||h==='localhost'||h.endsWith('.localhost')||h.endsWith('.local')||h.endsWith('.internal')||h.endsWith('.test')||h.endsWith('.invalid')||h.endsWith('.onion')||h==='metadata.google.internal'||!h.includes('.'))throw Error('Only public HTTPS hostnames are supported');
 return u;
}
export function htmlToText(html){return html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi,' ').replace(/<[^>]*>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'"').replace(/\s+/g,' ').trim();}
export function makeNode({title,content,sourceUrl='',tags=[],type='note'}){
 const date=new Date().toISOString();return {id:randomUUID(),title:String(title).slice(0,140),content:`${sourceUrl?`Source: ${sourceUrl}\nRetrieved: ${date}\n\n`:''}${String(content).slice(0,220000)}`,tags,type,createdAt:date,updatedAt:date};
}
async function fetchPublic(url){
 // Restrict domains for remote ingestion to Wikipedia/Wikimedia and explicitly approved public pages.
 const u=safePublicUrl(url);
 if(!/(^|\.)wikipedia\.org$|(^|\.)wikimedia\.org$|(^|\.)wiktionary\.org$|(^|\.)britannica\.com$/.test(u.hostname))throw Error('For security, remote fetching is currently limited to Wikipedia, Wikimedia, Wiktionary and Britannica');
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),12000);
 try {const r=await fetch(u,{redirect:'error',signal:controller.signal,headers:{'User-Agent':'ClaudeHive/0.3 (opt-in research importer)','Accept':'text/html, application/json'}});if(!r.ok)throw Error(`HTTP ${r.status}`);const len=Number(r.headers.get('content-length')||0);if(len>2_000_000)throw Error('Source too large');const text=await r.text();if(text.length>2_000_000)throw Error('Source too large');return {text,type:r.headers.get('content-type')||''};}finally{clearTimeout(timer);}
}
export async function importSource(kind,location){
 if(kind==='forum')return importForum(location);
 if(kind==='web'||kind==='wiki'){
 const u=safePublicUrl(location);const {text,type}=await fetchPublic(u.toString());if(!type.includes('text/html'))throw Error('Expected an HTML page');
 const title=(text.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||u.pathname.split('/').pop()||u.hostname).replace(/\s+/g,' ').trim();
 return makeNode({title,content:htmlToText(text),sourceUrl:u.toString(),tags:['web',kind==='wiki'?'encyclopedia':'reference']});
 }
 if(kind==='text'||kind==='image'){
 const path=resolve(location);const buf=await readFile(path);if(buf.byteLength>5_000_000)throw Error('File exceeds 5MB limit');
 const ext=extname(path).toLowerCase();
 if(kind==='text') {if(!['.txt','.md','.markdown'].includes(ext))throw Error('Text import supports .txt and .md');return makeNode({title:basename(path),content:buf.toString('utf8'),tags:['document']});}
 if(!['.png','.jpg','.jpeg','.webp','.gif'].includes(ext))throw Error('Unsupported image type');
 // Images are indexed as metadata only: no claim of image understanding or OCR.
 return makeNode({title:basename(path),content:`Image reference: ${basename(path)}\nSize: ${buf.byteLength} bytes\nNote: Image pixels are NOT interpreted. Add a human-written description for semantic search.`,tags:['image','reference']});
 }
 throw Error('Supported sources: wiki, web, forum, text, image');
}
if(import.meta.url===`file://${process.argv[1]}`){
 if(command!=='add'||!source||!out||!args[3]){console.error('Usage: node scripts/knowledge-sources.mjs add <wiki|web|forum|text|image> <URL-or-file> <output.json>');process.exitCode=1;}
 else {try{const node=await importSource(source,out);const target=resolve(args[3]);let existing={format:'claude-hive',version:1,nodes:[]};try{existing=JSON.parse(await readFile(target,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}if(existing.version!==1||!Array.isArray(existing.nodes))throw Error('Invalid Hive file');existing.nodes.push(node);await writeFile(target,JSON.stringify(existing,null,2));console.log(`Added ${node.title} to ${target}`);}catch(e){console.error(e.message);process.exitCode=1;}}
}
