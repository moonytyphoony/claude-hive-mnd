#!/usr/bin/env node
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {makePublicProfile,parsePublicProfile,profileToMarkdown} from '../assets/hive-profiles.js';
const [cmd,...args]=process.argv.slice(2);
async function main(){
 if(cmd==='create'){
  const [input,output]=args;if(!input||!output)throw Error('Usage: create draft.json profile.json');
  const draft=JSON.parse(await readFile(resolve(input),'utf8'));
  const profile=makePublicProfile(draft);
  await writeFile(resolve(output),JSON.stringify(profile,null,2)+'\n');
  console.log('Created portable public profile:',output);
 }else if(cmd==='inspect'){
  const [file]=args;if(!file)throw Error('Usage: inspect profile.json');
  const profile=parsePublicProfile(await readFile(resolve(file),'utf8'));
  console.log(JSON.stringify(profile,null,2));
 }else if(cmd==='instructions'){
  const [file]=args;if(!file)throw Error('Usage: instructions profile.json');
  const profile=parsePublicProfile(await readFile(resolve(file),'utf8'));
  console.log(profileToMarkdown(profile));
 }else throw Error('Usage: node scripts/hive-profile.mjs <create|inspect|instructions> ...');
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
