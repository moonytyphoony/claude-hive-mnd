import {lookup} from 'node:dns/promises';
import {isIP} from 'node:net';
import {safePublicUrl,htmlToText,makeNode} from './knowledge-sources.mjs';

function publicAddress(address) {
 if(!isIP(address))return false;
 if(address.includes(':')) {
  const x=address.toLowerCase();
  return !(x==='::1'||x==='::'||x.startsWith('fc')||x.startsWith('fd')||x.startsWith('fe8')||x.startsWith('fe9')||x.startsWith('fea')||x.startsWith('feb')||x.startsWith('::ffff:')||x.startsWith('2001:db8:'));
 }
 const a=address.split('.').map(Number);
 return !(a[0]===0||a[0]===10||a[0]===127||a[0]>=224||
 (a[0]===169&&a[1]===254)||(a[0]===172&&a[1]>=16&&a[1]<=31)||
 (a[0]===192&&a[1]===168)||(a[0]===100&&a[1]>=64&&a[1]<=127)||
 (a[0]===192&&a[1]===0)||(a[0]===198&&(a[1]===18||a[1]===19))||
 (a[0]===192&&a[1]===0&&a[2]===2)||(a[0]===198&&a[1]===51&&a[2]===100)||
 (a[0]===203&&a[1]===0&&a[2]===113));
}
export async function validateForumUrl(url,resolveAddresses=lookup) {
 const u=safePublicUrl(url);
 const records=await resolveAddresses(u.hostname,{all:true,verbatim:true});
 if(!records.length||records.some(r=>!publicAddress(r.address)))throw Error('Forum hostname resolves to a private or restricted network');
 return u;
}
export function extractForum(html,url) {
 const title=(html.match(/<meta\s+[^>]*property=["']og:title["'][^>]*content=["']([^"']+)/i)?.[1]||
 html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1]||new URL(url).pathname).trim();
 const stripped=html.replace(/<(?:header|footer|nav|aside)\b[^>]*>[\s\S]*?<\/(?:header|footer|nav|aside)>/gi,' ')
 .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ')
 .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ');
 const main=stripped.match(/<(?:main|article)\b[^>]*>([\s\S]*?)<\/(?:main|article)>/i)?.[1]||stripped;
 const text=htmlToText(main).slice(0,160000);
 if(text.length<40)throw Error('Not enough readable forum content. The site may require login or JavaScript rendering.');
 return {title:htmlToText(title).slice(0,140),text};
}
export async function importForum(url,{request=fetch,resolveAddresses=lookup}={}) {
 const u=await validateForumUrl(url,resolveAddresses);
 const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),12000);
 try{
  const r=await request(u.toString(),{redirect:'error',signal:controller.signal,headers:{'Accept':'text/html','User-Agent':'ClaudeHive/0.6 (+user-initiated-public-forum-import)'}});
  if(!r.ok)throw Error(`Forum returned HTTP ${r.status}`);
  if(!(r.headers.get('content-type')||'').toLowerCase().includes('text/html'))throw Error('Forum did not return HTML');
  if(Number(r.headers.get('content-length')||0)>2000000)throw Error('Forum page exceeds 2 MB');
  // Stream response to enforce size even when Content-Length is absent.
  const reader=r.body?.getReader();
  let html='';
  if(reader){
   const decoder=new TextDecoder();let bytes=0;
   while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>2000000){await reader.cancel();throw Error('Forum page exceeds 2 MB');}html+=decoder.decode(value,{stream:true});}
   html+=decoder.decode();
  }else{html=await r.text();if(Buffer.byteLength(html)>2000000)throw Error('Forum page exceeds 2 MB');}
  const {title,text}=extractForum(html,u.toString());
  return makeNode({title,content:text,sourceUrl:u.toString(),tags:['forum','development','reference']});
 }finally{clearTimeout(timer);}
}
