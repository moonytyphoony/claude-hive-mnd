#!/usr/bin/env node
/** Offline, opt-in YouTube transcript ingestion and adaptive context selection. */
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,basename,extname} from 'node:path';
import {randomUUID} from 'node:crypto';

export function youtubeId(input){
 const u=new URL(input);if(u.protocol!=='https:')throw Error('YouTube URL must use HTTPS');
 const host=u.hostname.toLowerCase();let id;
 if(host==='youtu.be'||host==='www.youtu.be')id=u.pathname.split('/')[1];
 else if(['youtube.com','www.youtube.com','m.youtube.com'].includes(host)){
  if(u.pathname==='/watch')id=u.searchParams.get('v');
  else if(/^\/(shorts|live|embed)\//.test(u.pathname))id=u.pathname.split('/')[2];
 }
 if(!id||!(/^[A-Za-z0-9_-]{11}$/).test(id))throw Error('Invalid or unsupported YouTube video URL');
 return id;
}
export function parseTranscript(text,filename='transcript.txt'){
 if(extname(filename).toLowerCase()==='.vtt'){
  const cues=[];for(const block of text.replace(/\r/g,'').split(/\n\s*\n/)){
   const lines=block.split('\n');const i=lines.findIndex(l=>l.includes('-->'));
   if(i<0)continue;
   const start=lines[i].split('-->')[0].trim();
   const body=lines.slice(i+1).join(' ').replace(/<[^>]+>/g,'').trim();
   if(body&&body!==cues.at(-1)?.text)cues.push({time:start,text:body});
  }return cues;
 }
 return text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean).map(x=>({time:'',text:x}));
}
export function transcriptToNode(url,transcript,{title='YouTube video',tags=[]}={}){
 const id=youtubeId(url);if(!Array.isArray(transcript)||!transcript.length)throw Error('Transcript is empty');
 const content=transcript.map(x=>`${x.time?`[${x.time}] `:''}${x.text}`).join('\n').slice(0,220000);
 const now=new Date().toISOString();return {id:randomUUID(),title,content:`Source: https://www.youtube.com/watch?v=${id}\nSource type: user-provided transcript (not independently verified)\n\n${content}`,tags:['youtube','video','reference',...tags],type:'note',createdAt:now,updatedAt:now};
}
function terms(s){return new Set((s.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu)||[]).filter(x=>!new Set(['the','and','for','with','from','this','that','are','was','you','have','about']).has(x)));}
export function adaptiveContext(query,nodes,{budget=3000,perSource=900,maxSources=8}={}){
 if(!Number.isInteger(budget)||budget<100||budget>100000)throw Error('budget must be 100..100000 characters');
 const q=terms(query);const candidates=[];
 for(const node of nodes){
  const content=String(node.content||'');const lines=content.split(/\n/).filter(Boolean);
  const title=String(node.title||'');const titleTerms=terms(title);
  const titleScore=[...q].filter(t=>titleTerms.has(t)).length*5;
  const ranked=lines.map((line,i)=>({line,i,score:[...q].filter(t=>terms(line).has(t)).length})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.i-b.i);
  if(!ranked.length&&!titleScore)continue;
  const selected=ranked.slice(0,8).sort((a,b)=>a.i-b.i).map(x=>x.line).join('\n').slice(0,perSource);
  candidates.push({title,id:node.id,score:titleScore+ranked.slice(0,8).reduce((s,x)=>s+x.score,0),excerpt:selected||content.slice(0,perSource),source:(content.match(/^Source:\s*(https:\/\/\S+)/m)||[])[1]||null});
 }
 candidates.sort((a,b)=>b.score-a.score||a.title.localeCompare(b.title));
 let used=0;const selected=[];
 for(const c of candidates.slice(0,maxSources)){
  const prefix=`## ${c.title}\n${c.source?`Source: ${c.source}\n`:''}`;
  const available=budget-used-prefix.length-2;if(available<40)break;
  const excerpt=c.excerpt.slice(0,available);selected.push({...c,excerpt});used+=prefix.length+excerpt.length+2;
 }
 const context=selected.map(x=>`## ${x.title}\n${x.source?`Source: ${x.source}\n`:''}${x.excerpt}`).join('\n\n');
 return {context,selected,characters:context.length,estimatedTokens:Math.ceil(context.length/4),note:'Character-based estimate, not actual model tokenization. Matching is lexical, not semantic.'};
}
async function main(){
 const [cmd,...args]=process.argv.slice(2);
 if(cmd==='youtube'){
  const [url,transcriptFile,hiveFile,title]=args;if(!url||!transcriptFile||!hiveFile)throw Error('Usage: youtube <YouTube URL> <transcript.txt|.vtt> <hive.json> [title]');
  const raw=await readFile(resolve(transcriptFile),'utf8');if(raw.length>1000000)throw Error('Transcript exceeds 1MB');
  const node=transcriptToNode(url,parseTranscript(raw,transcriptFile),{title:title||basename(transcriptFile)});
  let hive={format:'claude-hive',version:1,nodes:[]};try{hive=JSON.parse(await readFile(resolve(hiveFile),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
  if(hive.version!==1||!Array.isArray(hive.nodes))throw Error('Invalid Hive JSON');hive.nodes.push(node);await writeFile(resolve(hiveFile),JSON.stringify(hive,null,2));console.log(`Added video transcript: ${node.title}`);
 }else if(cmd==='context'){
  const [hiveFile,query,...flags]=args;if(!hiveFile||!query)throw Error('Usage: context <hive.json> "query" [--budget 3000]');
  const idx=flags.indexOf('--budget');const budget=idx<0?3000:Number(flags[idx+1]);const hive=JSON.parse(await readFile(resolve(hiveFile),'utf8'));
  console.log(adaptiveContext(query,hive.nodes,{budget}).context);
 }else throw Error('Commands: youtube, context');
}
if(import.meta.url===`file://${process.argv[1]}`)main().catch(e=>{console.error(e.message);process.exitCode=1;});
