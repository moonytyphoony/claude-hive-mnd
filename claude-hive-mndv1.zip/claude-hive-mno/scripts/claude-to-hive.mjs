#!/usr/bin/env node
// Optional Claude Code JSONL converter. Does NOT run automatically.
import {readFile,writeFile,readdir,stat} from 'node:fs/promises';
import {resolve,extname,basename,join} from 'node:path';
import {randomUUID} from 'node:crypto';
const [, , inputPath, outputPath] = process.argv;
if(!inputPath||!outputPath){console.error('Usage: node scripts/claude-to-hive.mjs <your-selected-jsonl-file-or-folder> <output.json>');process.exit(1);}
async function gather(p){const s=await stat(p);if(s.isFile())return extname(p)==='.jsonl'?[p]:[];const out=[];for(const name of await readdir(p)){const next=join(p,name),st=await stat(next);if(st.isFile()&&extname(next)==='.jsonl')out.push(next);}return out;}
function content(msg){const body=msg?.message?.content??msg?.content;if(typeof body==='string')return body;if(Array.isArray(body))return body.filter(b=>b?.type==='text'&&typeof b.text==='string').map(b=>b.text).join('\n');return '';}
const files=await gather(resolve(inputPath)),nodes=[];
for(const filename of files){const lines=(await readFile(filename,'utf8')).split(/\r?\n/);let contents=[],title='',firstDate='';for(const line of lines){if(!line.trim())continue;let o;try{o=JSON.parse(line);}catch{continue;}if(!['user','assistant'].includes(o.type))continue;const t=content(o).trim();if(!t)continue;if(!firstDate&&o.timestamp)firstDate=o.timestamp;if(!title&&o.type==='user')title=t.replace(/\s+/g,' ').slice(0,110);contents.push(`${o.type==='user'?'You':'Claude'}: ${t.slice(0,10000)}`);}
 if(!contents.length)continue;nodes.push({id:randomUUID(),title:title||basename(filename),content:contents.join('\n\n').slice(0,250000),tags:['claude-code'],type:'conversation',createdAt:firstDate||new Date().toISOString(),updatedAt:new Date().toISOString()});}
const out={format:'claude-hive',version:1,exportedAt:new Date().toISOString(),nodes};await writeFile(resolve(outputPath),JSON.stringify(out,null,2));console.log(`Exported ${nodes.length} conversations to ${resolve(outputPath)}`);
