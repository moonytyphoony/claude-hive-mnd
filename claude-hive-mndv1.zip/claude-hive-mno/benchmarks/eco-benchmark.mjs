/** Reproducible offline benchmark. Measures only example output/context sizes, NOT billed tokens. */
import {condenseLog,packHive,proxyTokens} from '../scripts/eco-core.mjs';
const hugeLog=Array.from({length:700},(_,i)=>`✓ component-${i} checked in 4ms`).join('\n')+'\nTests: 700 passed, 700 total\nTime: 5.1 s\n';
const smallLog='✓ 6 tests passed\n';
const errorLog=hugeLog+'\nError: migration failure\n';
const cases=[['large passing test log',hugeLog,{command:'npm test'}],['short passing test log',smallLog,{command:'npm test'}],['large failing log',errorLog,{command:'npm test'}],['unrelated command',hugeLog,{command:'cat secret.txt'}]];
console.log('ECO OFFLINE BENCHMARK — characters/4 proxy, not measured Claude tokens or cost');
for(const [label,raw,rest] of cases){const r=condenseLog(raw,{mode:'balanced',...rest});const before=proxyTokens(raw),after=proxyTokens(r.output);console.log(`${label}: ~${before} → ~${after} proxy tokens (${before?((before-after)/before*100).toFixed(1):'0'}% example-result reduction); ${r.reason}`);}
const nodes=[
 {id:'focus',title:'Knowledge retrieval design',tags:['rag','citations'],content:'Source: https://en.wikipedia.org/wiki/Knowledge_graph\n\nRAG selects relevant source passages rather than inserting entire libraries. Use citations for factual claims.\n'.repeat(50)},
 ...Array.from({length:50},(_,i)=>({id:'other-'+i,title:'Other research '+i,tags:['design'],content:'Unrelated interface styling reference. '.repeat(70)}))
];
const raw=nodes.map(n=>n.content).join('\n'),packed=packHive(nodes,'retrieval source citations',{budget:900});
console.log(`query-focused Hive pack: ~${proxyTokens(raw)} source proxy tokens → ~${packed.proxyTokens} selected proxy tokens (${((1-packed.proxyTokens/proxyTokens(raw))*100).toFixed(1)}% example-context reduction); ${packed.selected.length} excerpts`);
console.log('Note: reduction in selected context does NOT imply equal reduction in TOTAL tokens, latency, cost or improved answer quality. No Ponytail/Caveman comparison is performed.');
